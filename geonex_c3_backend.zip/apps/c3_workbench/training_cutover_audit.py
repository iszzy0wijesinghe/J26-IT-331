"""Read-only GeoNex C3 training-store cutover audit.

Never switches runtime connections or mutates either database. Detects drift
between the Phase 1A snapshot and Golden DB before service migration.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
from pathlib import Path

TABLES = ('c3_datasets', 'c3_training_jobs', 'c3_training_events', 'c3_model_versions')

def _open_readonly(path: Path) -> sqlite3.Connection:
    if not path.is_file():
        raise FileNotFoundError(f'Database does not exist: {path}')
    conn = sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True)
    conn.row_factory = sqlite3.Row
    return conn

def _fingerprint(conn: sqlite3.Connection, table: str) -> dict:
    # Deterministic snapshot fingerprint: include column names and all values.
    columns = [row['name'] for row in conn.execute(f'PRAGMA table_info("{table}")')]
    if not columns:
        raise ValueError(f'Missing table: {table}')
    ordered = [tuple(row) for row in conn.execute(f'SELECT * FROM "{table}"')]
    encoded = [json.dumps(list(row), ensure_ascii=False, separators=(',', ':'), default=str) for row in ordered]
    encoded.sort()
    digest = hashlib.sha256()
    digest.update(json.dumps(columns, separators=(',', ':')).encode())
    for line in encoded:
        digest.update(b'\n')
        digest.update(line.encode())
    return {'rows': len(ordered), 'sha256': digest.hexdigest()}

def audit(source: Path, target: Path) -> dict:
    if source.resolve() == target.resolve():
        raise ValueError('Golden and training databases must have different paths')
    with _open_readonly(source) as src, _open_readonly(target) as dst:
        source_data = {table: _fingerprint(src, table) for table in TABLES}
        target_data = {table: _fingerprint(dst, table) for table in TABLES}
        drift = [table for table in TABLES if source_data[table] != target_data[table]]
        target_tables = {row['name'] for row in dst.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        forbidden = sorted(target_tables.intersection({'c3_golden_observations', 'c3_forecast_runs', 'c3_forecast_values', 'c3_alert_events'}))
        foreign_key_errors = len(dst.execute('PRAGMA foreign_key_check').fetchall())
        integrity = dst.execute('PRAGMA integrity_check').fetchone()[0]
        ready_snapshot = not drift and not forbidden and not foreign_key_errors and integrity == 'ok'
        return {
            'source': str(source.resolve()), 'target': str(target.resolve()),
            'source_tables': source_data, 'training_tables': target_data,
            'drifted_tables': drift, 'unexpected_operational_tables': forbidden,
            'training_foreign_key_errors': foreign_key_errors, 'training_integrity': integrity,
            'snapshot_matches': ready_snapshot,
            'runtime_cutover_approved': False,
            'reason': 'Training writers/readers, dataset provenance and cross-store foreign keys have not been fully migrated and integration-tested.'
        }

def main() -> None:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=root/'data/workbench/c3/golden/c3_golden.sqlite3')
    parser.add_argument('--target', type=Path, default=root/'data/workbench/c3/training/c3_training.sqlite3')
    args = parser.parse_args()
    result = audit(args.source, args.target)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['snapshot_matches'] else 2)

if __name__ == '__main__':
    main()
